# Scope-Lifetime-Aware Two-Tier Symbol Table - Overleaf Compilation Guide

## Files Included
- `main.tex`: Full research manuscript and architectural monograph.
- `figures/`: Publication-quality IEEE vector (PDF) and 300 DPI raster (PNG) charts.
- `references.bib`: BibTeX citations for dragon book, Knuth TAOCP, Bloom filters, etc.

## How to Compile on Overleaf
1. Log in to [Overleaf](https://www.overleaf.com/).
2. Click **New Project** -> **Upload Project**.
3. Select this `manuscript_overleaf.zip` archive.
4. Set compiler to **pdfLaTeX** or **LaTeX** (default is pdfLaTeX, TeX Live 2024+).
5. Click **Recompile**.

## Local Compilation
```bash
pdflatex main.tex
bibtex main || true
pdflatex main.tex
pdflatex main.tex
```
